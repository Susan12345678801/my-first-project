# Climate Exposure and Financial Resilience in Regional Utilities

This project links annual SEC financial facts for twelve selected US utility companies to NOAA state climate observations and FEMA weather-related major-disaster declarations. The research question is whether headquarters-state climate exposure is associated with financial pressure and whether past climate information improves cash-flow prediction.


# Data Interpretation

The raw manifest records the successful URL, response size, UTC retrieval timestamp, content type and SHA-256 digest for every downloaded response. Requests were checked on 5 October 2026. These are actual JSON downloads, not search-result snippets.

## SEC EDGAR

Documentation: https://www.sec.gov/search-filings/edgar-application-programming-interfaces

Financial endpoint: `https://data.sec.gov/api/xbrl/companyfacts/CIK{10-digit-CIK}.json`

Business-address metadata: `https://data.sec.gov/submissions/CIK{10-digit-CIK}.json`

All financial units are USD. Only full calendar-year duration facts (a January 1 or preceding December 31 start) and December 31 instantaneous facts in original 10-K filings qualify, and later comparative restatements are not selected. A missing value remains missing; no financial values are imputed.

## NOAA NCEI Climate at a Glance

Service: https://www.ncei.noaa.gov/access/monitoring/climate-at-a-glance/

Temperature: `https://www.ncei.noaa.gov/access/monitoring/climate-at-a-glance/statewide/time-series/{state-code}/tavg/3/8/1981-2024.json`

Precipitation: `https://www.ncei.noaa.gov/access/monitoring/climate-at-a-glance/statewide/time-series/{state-code}/pcp/12/12/1981-2024.json`



## OpenFEMA

Documentation: https://www.fema.gov/openfema-data-page/disaster-declarations-summaries-v2

Endpoint: https://www.fema.gov/api/open/v2/DisasterDeclarationsSummaries
