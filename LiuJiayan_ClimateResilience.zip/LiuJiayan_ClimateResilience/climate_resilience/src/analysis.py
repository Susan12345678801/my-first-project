"""Exploratory panel analysis and chronological financial-pressure prediction."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import t
import statsmodels.formula.api as smf
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from .data_pipeline import ROOT
FIG=ROOT/'results/figures'; TAB=ROOT/'results/tables'
EXPOSURES=['heat_z','dry_z','log_disasters']
LABELS={'heat_z':'Summer temperature (1 SD)','dry_z':'Precipitation deficit (1 SD)','log_disasters':'log(1 + declarations)'}
COLORS=['#137E88','#D47732','#586AB0','#A45262']

def setup():
    FIG.mkdir(parents=True,exist_ok=True);TAB.mkdir(parents=True,exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold','figure.dpi':140,'savefig.dpi':180})

def save(fig,name):
    fig.savefig(FIG/f'{name}.pdf',bbox_inches='tight')
    fig.savefig(FIG/f'{name}.png',bbox_inches='tight')
    plt.close(fig)

def descriptive(panel):
    setup()
    table=panel.groupby(['ticker','state']).agg(n=('cfoa','count'),mean_roa=('roa','mean'),mean_cfoa=('cfoa','mean'),mean_liability_ratio=('liability_ratio','mean')).reset_index()
    table.to_csv(TAB/'company_summary.csv',index=False)
    climate=panel.drop_duplicates(['state','year'])
    hm=climate.pivot(index='state',columns='year',values='heat_z')
    fig,ax=plt.subplots(1,2,figsize=(10,3.5),gridspec_kw={'width_ratios':[3.5,1.3]})
    im=ax[0].imshow(hm.values,cmap='RdBu_r',vmin=-3,vmax=3,aspect='auto')
    ax[0].set(yticks=range(len(hm)),yticklabels=hm.index,xticks=range(len(hm.columns)),xticklabels=hm.columns,title='Summer temperature relative to 1981–2010')
    ax[0].tick_params(axis='x',rotation=60);fig.colorbar(im,ax=ax[0],label='Standard deviations',shrink=.85)
    d=climate.groupby('state').disasters.mean().reindex(hm.index)
    ax[1].barh(d.index,d,color=COLORS[0]);ax[1].invert_yaxis();ax[1].set(xlabel='Mean declarations / year',title='Weather-related disasters')
    fig.tight_layout();save(fig,'01_exposure')
    fig,axs=plt.subplots(1,2,figsize=(10,3.3),sharex=True)
    cmap=plt.get_cmap('tab20')
    for j,(ticker,g) in enumerate(panel.groupby('ticker')):
        for ax,col in zip(axs,['roa','cfoa']):ax.plot(g.year,100*g[col],label=ticker,color=cmap(j),lw=1.4,alpha=.9)
    for ax,label in zip(axs,['Net income / assets (%)','Operating cash flow / assets (%)']):
        ax.axhline(0,color='gray',lw=.6);ax.set(ylabel=label,xlabel='Year');ax.grid(alpha=.15)
    fig.legend(*axs[0].get_legend_handles_labels(),loc='lower center',ncol=6,bbox_to_anchor=(.5,-.09),frameon=False)
    fig.tight_layout();save(fig,'02_financial_paths')
    return table

def fit_panel(df,outcome,extra=''):
    formula=f'{outcome} ~ heat_z + dry_z + log_disasters + lag_liability_ratio + C(ticker) + C(year)'+extra
    cols=[outcome,*EXPOSURES,'lag_liability_ratio','ticker','year','state']
    d=df.dropna(subset=cols).copy()
    model=smf.ols(formula,d).fit(cov_type='cluster',cov_kwds={'groups':d.state,'use_correction':True},use_t=True)
    return model,d

def panel_models(panel):
    rows=[]
    for outcome in ['roa','cfoa']:
        model,d=fit_panel(panel,outcome)
        critical=t.ppf(.975,d.state.nunique()-1)
        for feature in EXPOSURES+['lag_liability_ratio']:
            value=model.params[feature];se=model.bse[feature]
            rows.append(dict(outcome=outcome,feature=feature,coefficient=value,se=se,ci_low=value-critical*se,ci_high=value+critical*se,n=len(d),clusters=d.state.nunique()))
    result=pd.DataFrame(rows);result.to_csv(TAB/'panel_coefficients.csv',index=False)
    fig,axs=plt.subplots(1,2,figsize=(10,3.2),sharey=True)
    for ax,outcome in zip(axs,['roa','cfoa']):
        d=result[(result.outcome==outcome)&result.feature.isin(EXPOSURES)].set_index('feature').loc[EXPOSURES]
        v=d.coefficient.to_numpy()*100
        ax.errorbar(v,range(3),xerr=np.vstack([v-d.ci_low.to_numpy()*100,d.ci_high.to_numpy()*100-v]),fmt='o',color=COLORS[0],capsize=4)
        ax.axvline(0,color='gray',lw=1,ls='--');ax.set(yticks=range(3),yticklabels=[LABELS[x] for x in EXPOSURES],xlabel='Percentage points',title='Profitability (ROA)' if outcome=='roa' else 'Operating cash flow / assets')
    axs[0].invert_yaxis();fig.tight_layout();save(fig,'03_panel_associations')
    return result

def buffer_analysis(panel):
    # The cut point is frozen on pre-2020 observations; it is not fitted to outcomes.
    d=panel.dropna(subset=['lag_liability_ratio','cfoa','roa']).copy()
    cutoff=float(d.loc[d.year<=2019,'lag_liability_ratio'].median())
    d['buffer']=np.where(d.lag_liability_ratio<=cutoff,'Lower liabilities','Higher liabilities')
    d['compound']=(d.heat_z>1)&(d.dry_z>1)
    d['exposure']=np.where(d.compound,'Hot and dry','Other years')
    summary=d.groupby(['buffer','exposure']).agg(n=('cfoa','size'),mean_cfoa=('cfoa','mean'),mean_roa=('roa','mean')).reset_index()
    summary['liability_cutoff']=cutoff;summary.to_csv(TAB/'buffer_groups.csv',index=False)
    checks=[]
    for sample,part in [('Full sample',d),('Exclude PCG',d[d.ticker!='PCG']),('Exclude 2020',d[d.year!=2020])]:
        for b in ['Lower liabilities','Higher liabilities']:
            g=part[part.buffer==b]; hot=g[g.compound]; other=g[~g.compound]
            checks.append(dict(sample=sample,buffer=b,hot_dry_n=len(hot),other_n=len(other),cfoa_difference=hot.cfoa.mean()-other.cfoa.mean()))
    pd.DataFrame(checks).to_csv(TAB/'buffer_sensitivity.csv',index=False)
    fig,axs=plt.subplots(1,2,figsize=(9.8,3.3))
    for ax,outcome,label in zip(axs,['cfoa','roa'],['Operating cash flow / assets (%)','Net income / assets (%)']):
        arrays=[]; labels=[]
        for b in ['Lower liabilities','Higher liabilities']:
            for e in ['Other years','Hot and dry']:
                g=d[(d.buffer==b)&(d.exposure==e)]
                arrays.append(100*g[outcome]); labels.append(f'{b.split()[0]}\n{e}\n(n={len(g)})')
        box=ax.boxplot(arrays,tick_labels=labels,patch_artist=True,widths=.6,flierprops={'markersize':3})
        for patch,c in zip(box['boxes'],[COLORS[0],COLORS[1]]*2):patch.set_facecolor(c);patch.set_alpha(.6)
        ax.axhline(0,color='gray',lw=.6);ax.set(ylabel=label);ax.tick_params(axis='x',labelsize=8)
    fig.tight_layout();save(fig,'04_buffers')
    return summary

def model_pipeline(numeric,alpha):
    trans=ColumnTransformer([('number',StandardScaler(),numeric),('firm',OneHotEncoder(handle_unknown='ignore',sparse_output=False),['ticker'])])
    return make_pipeline(trans,Ridge(alpha=alpha))

def prediction(panel):
    finance=['lag_roa','lag_cfoa','lag_liability_ratio']
    extra=['lag_heat_z','lag_dry_z','lag_log_disasters']
    df=panel.dropna(subset=['cfoa',*finance,*extra]).copy()
    train=df[df.year<=2019];valid=df[df.year.between(2020,2021)];test=df[df.year.between(2022,2024)]
    assert train.year.max()<valid.year.min()<test.year.min()
    metrics=[];pred=test[['ticker','state','year','cfoa']].copy();tuning=[]
    pred['Historical mean']=df.loc[df.year<=2021,'cfoa'].mean();pred['Persistence']=test.lag_cfoa
    for label,features in [('Finance only',finance),('Finance + climate',finance+extra)]:
        scores=[]
        for alpha in [.1,1,10,100]:
            model=model_pipeline(features,alpha).fit(train[features+['ticker']],train.cfoa)
            rmse=float(np.sqrt(mean_squared_error(valid.cfoa,model.predict(valid[features+['ticker']]))))
            scores.append((rmse,alpha));tuning.append(dict(model=label,alpha=alpha,validation_rmse=rmse))
        _,alpha=min(scores)
        fitting=pd.concat([train,valid])
        model=model_pipeline(features,alpha).fit(fitting[features+['ticker']],fitting.cfoa)
        pred[label]=model.predict(test[features+['ticker']])
    for label in ['Historical mean','Persistence','Finance only','Finance + climate']:
        metrics.append(dict(model=label,n=len(test),mae=mean_absolute_error(test.cfoa,pred[label]),rmse=np.sqrt(mean_squared_error(test.cfoa,pred[label])),r2=r2_score(test.cfoa,pred[label]),selected_alpha=next((min((r['validation_rmse'],r['alpha']) for r in tuning if r['model']==label)[1] for _ in [0] if any(r['model']==label for r in tuning)),np.nan)))
    metrics=pd.DataFrame(metrics);metrics.to_csv(TAB/'prediction_metrics.csv',index=False)
    pd.DataFrame(tuning).to_csv(TAB/'validation_scores.csv',index=False)
    pred.to_csv(TAB/'test_predictions.csv',index=False)
    # Paired state bootstrap retains the dependence between firms in one state.
    rng=np.random.default_rng(20261005);states=pred.state.unique();diffs=[]
    for _ in range(2000):
        b=pd.concat([pred[pred.state==s] for s in rng.choice(states,len(states),replace=True)])
        diffs.append(np.sqrt(mean_squared_error(b.cfoa,b['Finance + climate']))-np.sqrt(mean_squared_error(b.cfoa,b['Finance only'])))
    interval=np.quantile(diffs,[.025,.975])
    audit=dict(train_n=len(train),validation_n=len(valid),test_n=len(test),rmse_difference=float(metrics.set_index('model').loc['Finance + climate','rmse']-metrics.set_index('model').loc['Finance only','rmse']),paired_state_bootstrap_95=interval.tolist(),bootstrap_repetitions=2000)
    (TAB/'prediction_audit.json').write_text(json.dumps(audit,indent=2))
    fig,axs=plt.subplots(1,2,figsize=(10,3.5))
    axs[0].barh(metrics.model,100*metrics.rmse,color=[*COLORS[:2],COLORS[2],COLORS[3]])
    axs[0].invert_yaxis();axs[0].set(xlabel='Test RMSE (percentage points)',title='Held-out years: 2022–2024')
    for label,c in [('Finance only',COLORS[2]),('Finance + climate',COLORS[3])]:
        axs[1].scatter(100*pred.cfoa,100*pred[label],s=22,label=label,color=c,alpha=.8)
    lo=min(pred.cfoa.min(),pred[['Finance only','Finance + climate']].min().min())*100
    hi=max(pred.cfoa.max(),pred[['Finance only','Finance + climate']].max().max())*100
    axs[1].plot([lo,hi],[lo,hi],ls='--',color='gray',lw=1);axs[1].set(xlabel='Observed cash flow / assets (%)',ylabel='Predicted cash flow / assets (%)');axs[1].legend(frameon=False,fontsize=8)
    fig.tight_layout();save(fig,'05_prediction')
    return metrics,audit

def sensitivity(panel):
    rows=[]
    cases=[('Full sample',panel),('Exclude PCG',panel[panel.ticker!='PCG']),('Exclude 2020',panel[panel.year!=2020])]
    cases += [(f'Without {s}',panel[panel.state!=s]) for s in sorted(panel.state.unique())]
    for name,d in cases:
        for outcome in ['roa','cfoa']:
            model,used=fit_panel(d,outcome)
            rows.append(dict(sample=name,outcome=outcome,heat_coefficient=model.params['heat_z'],n=len(used)))
    result=pd.DataFrame(rows);result.to_csv(TAB/'sensitivity.csv',index=False)
    fig,axs=plt.subplots(1,2,figsize=(10,3.8),sharey=True)
    for ax,outcome in zip(axs,['roa','cfoa']):
        d=result[result.outcome==outcome]
        ax.scatter(100*d.heat_coefficient,d['sample'],c=[COLORS[1]]*3+[COLORS[0]]*(len(d)-3),s=27)
        ax.axvline(0,color='gray',lw=1,ls='--');ax.set(xlabel='Heat coefficient (percentage points / SD)',title='Profitability (ROA)' if outcome=='roa' else 'Operating cash flow / assets');ax.tick_params(axis='y',labelsize=8)
    axs[0].invert_yaxis();fig.tight_layout();save(fig,'06_sensitivity')
    return result

def run_all(panel):
    return {'descriptive':descriptive(panel),'panel':panel_models(panel),'buffers':buffer_analysis(panel),'prediction':prediction(panel),'sensitivity':sensitivity(panel)}
