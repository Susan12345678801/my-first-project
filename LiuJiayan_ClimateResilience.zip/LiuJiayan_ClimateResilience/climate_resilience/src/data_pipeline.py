"""Download, validate and align public financial and climate observations."""
from pathlib import Path
import os, json, time, hashlib
from datetime import datetime, timezone
import requests
import pandas as pd
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'data/raw'
PROCESSED = ROOT / 'data/processed'
START, END = 2011, 2024
WEATHER_TYPES = ['Coastal Storm','Drought','Fire','Flood','Freezing','Hurricane','Severe Ice Storm','Severe Storm','Snowstorm','Tornado','Tropical Storm']

def fetch_json(url, filename, force=False):
    """Read a checked cache or GET an actual JSON body, with retry and audit log."""
    path = RAW / filename
    manifest_path = RAW / 'download_manifest.json'
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
    if path.exists() and not force:
        body = path.read_bytes()
        if filename not in manifest or hashlib.sha256(body).hexdigest() != manifest[filename]['sha256']:
            raise ValueError(f'Cache checksum mismatch: {filename}')
        return json.loads(body)
    headers = {'User-Agent': os.environ.get('SEC_USER_AGENT','ClimateResilienceResearch public-data-analysis')}
    for attempt in range(4):
        try:
            response = requests.get(url, headers=headers, timeout=(15,90))
            response.raise_for_status()
            obj = response.json()
            if not isinstance(obj, dict): raise ValueError('Expected a JSON object')
            body = response.content
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(body)
            manifest[filename] = dict(url=response.url, status=response.status_code,
                retrieved_utc=datetime.now(timezone.utc).isoformat(), bytes=len(body),
                content_type=response.headers.get('Content-Type'),sha256=hashlib.sha256(body).hexdigest())
            manifest_path.write_text(json.dumps(manifest,indent=2))
            time.sleep(0.25)
            return obj
        except (requests.RequestException, ValueError):
            if attempt == 3: raise
            time.sleep(2 ** attempt)

def download_all(force=False):
    companies = pd.read_csv(ROOT/'data/companies.csv')
    for c in companies.itertuples():
        for kind, url in [('facts',f'https://data.sec.gov/api/xbrl/companyfacts/CIK{c.cik:010d}.json'),
                          ('submissions',f'https://data.sec.gov/submissions/CIK{c.cik:010d}.json')]:
            fetch_json(url,f'{c.ticker}_{kind}.json',force)
        print(f'Checked SEC data: {c.ticker}', flush=True)
    for state,code in companies[['state','noaa_state']].drop_duplicates().itertuples(index=False):
        for variable, window, month in [('tavg',3,8),('pcp',12,12)]:
            url=f'https://www.ncei.noaa.gov/access/monitoring/climate-at-a-glance/statewide/time-series/{code}/{variable}/{window}/{month}/1981-2024.json'
            fetch_json(url,f'{state}_{variable}.json',force)
        print(f'Checked NOAA data: {state}', flush=True)
    # Full pagination is essential: FEMA returns many county/program rows per event.
    base='https://www.fema.gov/api/open/v2/DisasterDeclarationsSummaries'
    filt="declarationType eq 'DR' and incidentBeginDate ge '2011-01-01T00:00:00.000Z' and incidentBeginDate lt '2025-01-01T00:00:00.000Z'"
    skip=0
    while True:
        url=requests.Request('GET',base,params={'$filter':filt,'$top':1000,'$skip':skip,'$orderby':'id'}).prepare().url
        obj=fetch_json(url,f'fema_{skip:05d}.json',force)
        if len(obj['DisasterDeclarationsSummaries']) < 1000: break
        skip+=1000
    # Remove obsolete tail pages only after a successful refresh has completed.
    if force:
        manifest_path=RAW/'download_manifest.json'
        manifest=json.loads(manifest_path.read_text())
        for old in RAW.glob('fema_*.json'):
            if int(old.stem.split('_')[1])>skip:
                old.unlink();manifest.pop(old.name,None)
        manifest_path.write_text(json.dumps(manifest,indent=2))
    return pd.DataFrame(json.loads((RAW/'download_manifest.json').read_text())).T

def read_raw(name): return json.loads((RAW/name).read_text())

def choose_fact(facts, tags, year, duration, accession=None):
    """Use the earliest eligible 10-K; preserve period, tag and filing provenance."""
    for tag in tags:
        rows=facts.get(tag,{}).get('units',{}).get('USD',[])
        valid=[]
        for r in rows:
            if r.get('form')!='10-K' or r.get('end')!=f'{year}-12-31': continue
            if r.get('filed','9999') > f'{year+1}-05-01': continue
            if r.get('filed','0000') < f'{year+1}-01-01': continue
            if accession and r.get('accn') != accession: continue
            if duration:
                if r.get('start') not in [f'{year}-01-01', f'{year-1}-12-31']: continue
            elif 'start' in r: continue
            valid.append(r)
        if valid:
            r=sorted(valid,key=lambda x:(x['filed'],x['accn']))[0].copy()
            r['tag']=tag
            r['unit']='USD'
            return r
    return None

def financial_panel():
    rows=[]; provenance=[]; missing=[]; companies=pd.read_csv(ROOT/'data/companies.csv')
    concepts={'assets':(['Assets'],False),'liabilities':(['Liabilities'],False),
              'income':(['NetIncomeLoss','ProfitLoss'],True),
              'ocf':(['NetCashProvidedByUsedInOperatingActivities'],True)}
    for c in companies.itertuples():
        obj=read_raw(f'{c.ticker}_facts.json'); sub=read_raw(f'{c.ticker}_submissions.json')
        assert int(obj['cik'])==c.cik
        assert sub['sic'] in ['4911','4931'], (c.ticker, sub['name'])
        assert c.ticker in sub['tickers'] or (c.ticker=='PNM' and 'TXNM' in sub['tickers']) or (c.ticker=='ALE' and 'ALLETE' in sub['name'].upper())
        assert sub['addresses']['business']['stateOrCountry']==c.state, (c.ticker,sub['addresses'])
        facts=obj['facts']['us-gaap']
        for y in range(START,END+1):
            anchor=choose_fact(facts,['NetCashProvidedByUsedInOperatingActivities'],y,True)
            row=dict(ticker=c.ticker,state=c.state,year=y,company=obj['entityName'])
            for key,(tags,duration) in concepts.items():
                r=choose_fact(facts,tags,y,duration,anchor['accn']) if anchor else None
                if key=='liabilities' and r is None and anchor:
                    current=choose_fact(facts,['LiabilitiesCurrent'],y,False,anchor['accn'])
                    noncurrent=choose_fact(facts,['LiabilitiesNoncurrent'],y,False,anchor['accn'])
                    equity=choose_fact(facts,['StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest'],y,False,anchor['accn'])
                    if equity and np.isfinite(row['assets']):
                        # This broad proxy includes claims outside total equity.
                        r=equity.copy();r['val']=row['assets']-equity['val'];r['tag']='Assets - StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest'
                        provenance.append(dict(ticker=c.ticker,year=y,variable='liabilities_component',**equity))
                    elif current and noncurrent:
                        r=current.copy();r['val']=current['val']+noncurrent['val'];r['tag']='LiabilitiesCurrent + LiabilitiesNoncurrent'
                        for component in [current,noncurrent]:provenance.append(dict(ticker=c.ticker,year=y,variable='liabilities_component',**component))
                row[key]=float(r['val']) if r else np.nan
                if r: provenance.append(dict(ticker=c.ticker,year=y,variable=key,**r))
                else: missing.append(dict(ticker=c.ticker,year=y,variable=key))
            rows.append(row)
    df=pd.DataFrame(rows)
    assert not df.duplicated(['ticker','year']).any()
    assert df.assets.dropna().gt(0).all()
    assert df.liabilities.dropna().ge(0).all()
    for col, numerator in [('roa','income'),('cfoa','ocf'),('liability_ratio','liabilities')]:
        df[col]=df[numerator]/df.assets
    pd.DataFrame(provenance).to_csv(PROCESSED/'financial_provenance.csv',index=False)
    pd.DataFrame(missing,columns=['ticker','year','variable']).to_csv(PROCESSED/'missing_financial_facts.csv',index=False)
    return df

def climate_panel():
    rows=[]; summary=[]
    for state in pd.read_csv(ROOT/'data/companies.csv').state.unique():
        series={}
        for variable in ['tavg','pcp']:
            obj=read_raw(f'{state}_{variable}.json')
            assert 'data' in obj and 'description' in obj
            vals=pd.Series({int(k[:4]):float(v['value']) for k,v in obj['data'].items()}).sort_index()
            assert set(range(1981,2025)) <= set(vals.index)
            assert vals.notna().all() and vals.gt(-90).all()
            if variable=='pcp': assert vals.ge(0).all()
            base=vals.loc[1981:2010]
            assert len(base)==30 and base.std(ddof=1)>0
            series[variable]=vals
            series[variable+'_z']=(vals-base.mean())/base.std(ddof=1)
            summary.append(dict(state=state,variable=variable,title=obj['description']['title'],units=obj['description']['units'],baseline_mean=base.mean(),baseline_sd=base.std(ddof=1)))
        for y in range(START,END+1):
            rows.append(dict(state=state,year=y,summer_temp_f=series['tavg'][y],precip_in=series['pcp'][y],heat_z=series['tavg_z'][y],dry_z=-series['pcp_z'][y]))
    pd.DataFrame(summary).to_csv(PROCESSED/'climate_baselines.csv',index=False)
    return pd.DataFrame(rows)

def disaster_panel():
    rows=[]
    for p in sorted(RAW.glob('fema_*.json')):
        rows.extend(json.loads(p.read_text())['DisasterDeclarationsSummaries'])
    df=pd.DataFrame(rows)
    required=['id','state','disasterNumber','incidentType','declarationType','incidentBeginDate']
    assert set(required)<=set(df.columns) and not df.id.duplicated().any()
    df['year']=pd.to_datetime(df.incidentBeginDate).dt.year
    kept=df[(df.declarationType=='DR') & df.incidentType.isin(WEATHER_TYPES) & df.year.between(START,END)].copy()
    kept=kept.drop_duplicates(['state','disasterNumber'])
    kept[['state','disasterNumber','incidentType','incidentBeginDate','year']].to_csv(PROCESSED/'weather_disasters.csv',index=False)
    counts=kept.groupby(['state','year']).size().rename('disasters').reset_index()
    return counts, {'fema_raw_rows':len(df),'fema_unique_weather_state_events_all_states':len(kept)}

def build_panel():
    PROCESSED.mkdir(parents=True,exist_ok=True)
    financial=financial_panel(); climate=climate_panel(); disaster, audit=disaster_panel()
    climate=climate.merge(disaster,on=['state','year'],how='left',validate='one_to_one')
    climate['disasters']=climate.disasters.fillna(0).astype(int)
    climate['log_disasters']=np.log1p(climate.disasters)
    panel=financial.merge(climate,on=['state','year'],how='left',validate='many_to_one').sort_values(['ticker','year'])
    assert len(panel)==len(financial)
    assert panel[['heat_z','dry_z','disasters']].notna().all().all()
    for c in ['roa','cfoa','liability_ratio','heat_z','dry_z','log_disasters']:
        panel['lag_'+c]=panel.groupby('ticker')[c].shift()
    panel.to_csv(PROCESSED/'panel.csv',index=False)
    climate.to_csv(PROCESSED/'state_climate.csv',index=False)
    audit.update(company_years=len(panel),firms=panel.ticker.nunique(),states=panel.state.nunique(),complete_financial_rows=int(panel[['assets','income','ocf','liabilities']].notna().all(axis=1).sum()),years=[START,END])
    (PROCESSED/'validation_summary.json').write_text(json.dumps(audit,indent=2))
    return panel,audit
